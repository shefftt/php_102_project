<a class="btn btn-success" href="http://localhost/project/index.php/users/creat">اضافة مستخدم</a>

<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>الاسم</th>
            <th>البريد</th>
            <th class="text-right">الضبط</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user) : ?>
        <tr>
            <td class="text-center">1</td>
            <td><?= $user->name ?></td>
            <td><?= $user->email ?></td>
            <td>
                <a class="btn btn-sm btn-info" href="http://localhost/project/index.php/users/edit/<?= $user->id ?>">تعديل</a>
                <a class="btn btn-sm btn-danger" href="http://localhost/project/index.php/users/delete/<?= $user->id ?>">حذف</a>
            </td>
        </tr>
    <?php endforeach; ?>

    </tbody>
</table>
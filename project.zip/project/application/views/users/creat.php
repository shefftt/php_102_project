<form action="http://localhost/project/index.php/users/post_creat" method="post">
  <div class="form-group">
     <label for="exampleInput1" class="bmd-label-floating">الاسم</label>
     <input type="text" name="name" class="form-control" id="exampleInput1">
  </div>


   <div class="form-group">
     <label for="exampleInput1" class="bmd-label-floating">البريد الالكتروني</label>
     <input type="email" name="email" class="form-control" id="exampleInput1">
  </div>


   <div class="form-group">
     <label for="exampleInput1" class="bmd-label-floating">كلمه السر</label>
     <input type="text" name="password" class="form-control" id="exampleInput1">
  </div>

<button class="btn btn-success">اضافة مستخدم</button>
 </form>
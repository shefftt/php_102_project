<form action="http://localhost/project/index.php/users/post_edit" method="post">
  <div class="form-group">
     <label for="exampleInput1" class="bmd-label-floating">الاسم</label>
     <input type="text" name="name" value="<?= $user->name ?>" class="form-control" id="exampleInput1">
  </div>


   <div class="form-group">
     <label for="exampleInput1" class="bmd-label-floating">البريد الالكتروني</label>
     <input type="email" name="email" value="<?= $user->email ?>"  class="form-control" id="exampleInput1">
     <input type="hidden" name="id" value="<?= $user->id ?>"  class="form-control" id="exampleInput1">
  </div>


   <div class="form-group">
     <label for="exampleInput1" class="bmd-label-floating">كلمه السر</label>
     <input type="text" name="password" value="<?= $user->password ?>"  class="form-control" id="exampleInput1">
  </div>

<button class="btn btn-success">تعديل </button>
 </form>
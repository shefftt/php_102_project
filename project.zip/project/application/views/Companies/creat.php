<form action="http://localhost/project/index.php/Companies/post_creat" method="post">
<div class="row">
	  <div class="form-group col-md-6 float-right">
     <label for="exampleInput1" class="bmd-label-floating">الاسم</label>
     <input type="text" name="name" class="form-control" id="exampleInput1">
  </div>

 <div class="form-group col-md-6 float-left">
     <label for="exampleInput1" class="bmd-label-floating">الهاتف</label>
     <input type="text" name="phone" class="form-control" id="exampleInput1">
  </div>

  	<div class="form-group col-md-12">
    <label for="exampleFormControlTextarea1" class="bmd-label-floating"">من نحن</label>
    <textarea class="form-control" name="about" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>

  </div>

  <button  class="btn btn-success">اضافه</button>
</form>
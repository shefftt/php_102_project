<a class="btn  btn-success" href="http://localhost/project/index.php/Companies/creat">اضافة شركه</a>

<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>اسم الشركه</th>
            <th>الهاتف</th>
            <th>من نحن</th>
            <th class="text-right">ضبط</th>
        </tr>
    </thead>
    <tbody>
    	<?php foreach ($companies as $company) : ?>
    
        <tr>
            <td class="text-center">1</td>
            <td><?= $company->name ?></td>
            <td><?= $company->phone ?></td>
            <td><?= $company->about ?></td>
            <td><a class="btn btn-sm btn-info" href="#">تعديل</a> <a class="btn btn-sm btn-danger" href="#">حذف</a> </td>
        </tr>
    <?php endforeach ?>
      
    </tbody>
</table>
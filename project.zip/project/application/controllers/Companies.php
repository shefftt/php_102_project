<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Companies extends CI_Controller {


    public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function index()
	{
		$data['companies'] = $this->db->get("Companies")->result();
		$data['file'] = "Companies/index.php";
		$this->load->view('templet' , $data);
	}


        /*

         * داله تقوم بعرض انشاء شكره جديده
         * 
         */
	public function creat()
	{
		$data['file'] = "Companies/creat.php";
		$this->load->view('templet' , $data);	
	}

	public function post_creat()
	{
		// companies `id`, `name`, `about`, `phone`, `created_at`
		$this->db->insert('companies' , array('name' => $_POST['name'] ,'phone' => $_POST['phone'] ,'about' => $_POST['about'] , ));
		redirect('companies','refresh');
	}


	
}

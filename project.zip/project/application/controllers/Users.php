<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {


    public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	public function index()
	{
		$data['users'] =  $this->db->get('users')->result();
		$data['file'] =  'users/index.php';
		$this->load->view('templet' , $data);
	}


	public function creat()
	{

		$data['file'] =  'users/creat.php';
		$this->load->view('templet' , $data);
		
	}


	public function post_creat()
	{
		$this->db->insert('users', array('name' => $_POST['name'] , 'email' => $_POST['email'] , 'password' => $_POST['password']));
		redirect('users','refresh');
	}

	public function edit($id)
	{
		$data['user'] = $this->db->get_where('users' , array('id' => $id))->row();

		$data['file'] =  'users/edit.php';
		$this->load->view('templet' , $data);

		
	}

	public function post_edit()
	{
		$this->db->where('id' , $_POST['id']);
		$this->db->update('users', array('name' => $_POST['name'] , 'email' => $_POST['email'] , 'password' => $_POST['password']));
		
		redirect('users','refresh');
	}


	public function delete($id)
	{
		$this->db->where('id' , $id);
		$this->db->delete('users');
		redirect('users','refresh');
	}


}